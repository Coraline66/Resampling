library(testthat)
library(Resampling)

test_check("Resampling")
